
chrome.action.onClicked.addListener((tab) => {
    chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
            const results = { external: [], inline: [] };
            const scripts = Array.from(document.scripts);
            scripts.forEach((script, index) => {
                if (script.src) {
                    results.external.push(script.src);
                } else {
                    results.inline.push({index: index, content: script.innerText});
                }
            });
            return results;
        }
    }, async (injectionResults) => {
        const data = injectionResults[0].result;
        const metadata = { external: [], inline: [] };

        const zip = new JSZip();

        // Last ned eksterne scripts
        for (const url of data.external) {
            try {
                const response = await fetch(url);
                const blob = await response.blob();
                const arrayBuffer = await blob.arrayBuffer();
                const filename = "external/" + url.split('/').pop();
                zip.file(filename, arrayBuffer);
                metadata.external.push({ url: url, filename: filename, size: blob.size });
            } catch (e) {
                console.error("Failed to fetch external script:", url);
            }
        }

        // Lagre inline scripts
        for (const inlineScript of data.inline) {
            const filename = "inline/inline_script_" + inlineScript.index + ".txt";
            zip.file(filename, inlineScript.content);
            metadata.inline.push({ index: inlineScript.index, filename: filename, size: inlineScript.content.length });
        }

        // Legg til metadata
        zip.file("metadata.json", JSON.stringify(metadata, null, 2));

        // Generer zip og trigger nedlasting
        const content = await zip.generateAsync({type:"blob"});
        const blobUrl = URL.createObjectURL(content);
        chrome.downloads.download({ url: blobUrl, filename: "scripts_extracted.zip" });
    });
});
